<?php

namespace FrontOffice\UserBundle;

class FrontOfficeUserEvents {

    const AFTER_ENTRAINEUR_REGISTER = "front_event.after_entraineur_register";

}
