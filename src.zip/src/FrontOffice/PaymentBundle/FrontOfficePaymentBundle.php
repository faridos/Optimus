<?php

namespace FrontOffice\PaymentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FrontOfficePaymentBundle extends Bundle
{
}
