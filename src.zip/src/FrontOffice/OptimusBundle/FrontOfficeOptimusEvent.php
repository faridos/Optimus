<?php

namespace FrontOffice\OptimusBundle;

class FrontOfficeOptimusEvent {
   
   const AFTER_EVENT_REGISTER = "front_event.after_event_register";
   const AFTER_CLUB_REGISTER = "front_event.after_club_register";
   const PARICIAPTION_REGISTER = "front_event.participation_register";
   const NOTIFICATION_CLUB = "front_event.notification_club";
   const NOTIFICATION_SEEN_USER = "front_event.notification_seen_user";
   
    
}
