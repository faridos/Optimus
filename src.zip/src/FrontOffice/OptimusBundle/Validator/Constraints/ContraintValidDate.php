<?php

namespace FrontOffice\OptimusBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;
/**
 *@Annotation
 */
class ContraintValidDate extends Constraint {
    public $date ='erreur';
    //put your code here
}
