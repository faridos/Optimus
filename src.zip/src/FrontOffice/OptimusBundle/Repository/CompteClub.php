<?php

namespace FrontOffice\OptimusBundle\Repository;

use Doctrine\ORM\EntityRepository;
class CompteClub extends EntityRepository {
    //put your code here
}
