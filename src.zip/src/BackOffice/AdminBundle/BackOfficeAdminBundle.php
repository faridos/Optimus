<?php

namespace BackOffice\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BackOfficeAdminBundle extends Bundle
{
}
